package com.masjid.tv.modern;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.media.*;import android.view.*;import java.text.*;import java.util.*;import java.util.concurrent.*;import org.json.*;import java.io.*;import java.net.*;import com.google.zxing.*;import com.google.zxing.common.BitMatrix;

public class MainActivity extends Activity {
  ModernView view; ExecutorService exec=Executors.newSingleThreadExecutor(); String[] names={"Fajr","Dhuhr","Asr","Maghrib","Isha"}; String[] azan=new String[5],jamaat=new String[5];
  String sunrise="--:--"; int active=0; long nextMillis=0; String nextName="--"; boolean countdownMode=false,bellPlayed=false; long countdownTarget=0; MediaPlayer bellPlayer;
  @Override public void onCreate(Bundle b){super.onCreate(b);fullscreen();view=new ModernView(this);setContentView(view);loadSaved();fetchTimes();}
  void fullscreen(){getWindow().setFlags(1024,1024);getWindow().getDecorView().setSystemUiVisibility(5894);}
  void loadSaved(){for(int i=0;i<5;i++){azan[i]=Prefs.azan(this,i);jamaat[i]=Prefs.jamaat(this,i);}}
  @Override protected void onResume(){super.onResume();fullscreen();if(view!=null){loadSaved();view.invalidate();}fetchTimes();}
  @Override protected void onDestroy(){if(bellPlayer!=null){bellPlayer.release();bellPlayer=null;}exec.shutdownNow();super.onDestroy();}
  void fetchTimes(){final String lat=Prefs.lat(this),lon=Prefs.lon(this),method=Prefs.method(this);exec.execute(()->{try{URL u=new URL("https://api.aladhan.com/v1/timings?latitude="+URLEncoder.encode(lat,"UTF-8")+"&longitude="+URLEncoder.encode(lon,"UTF-8")+"&method="+method);HttpURLConnection h=(HttpURLConnection)u.openConnection();h.setConnectTimeout(8000);h.setReadTimeout(8000);BufferedReader r=new BufferedReader(new InputStreamReader(h.getInputStream()));StringBuilder s=new StringBuilder();String line;while((line=r.readLine())!=null)s.append(line);r.close();JSONObject data=new JSONObject(s.toString()).getJSONObject("data"),t=data.getJSONObject("timings");String[] keys={"Fajr","Dhuhr","Asr","Maghrib","Isha"};for(int i=0;i<5;i++)azan[i]=to12(t.getString(keys[i]));sunrise=to12(t.getString("Sunrise"));JSONObject gd=data.getJSONObject("date").getJSONObject("gregorian"),hd=data.getJSONObject("date").getJSONObject("hijri");view.gregorian=gd.getString("weekday")+", "+gd.getString("date");view.hijri=hd.getJSONObject("month").getString("en")+" "+hd.getString("day")+", "+hd.getString("year");computeNext();runOnUiThread(()->view.invalidate());}catch(Exception e){computeNext();runOnUiThread(()->view.invalidate());}});}
  Calendar parseToday(String text){try{Date d=new SimpleDateFormat("hh:mm a",Locale.US).parse(text);Calendar now=Calendar.getInstance(),x=Calendar.getInstance();x.setTime(d);now.set(Calendar.HOUR_OF_DAY,x.get(Calendar.HOUR_OF_DAY));now.set(Calendar.MINUTE,x.get(Calendar.MINUTE));now.set(Calendar.SECOND,0);now.set(Calendar.MILLISECOND,0);return now;}catch(Exception e){return null;}}
  void computeNext(){long now=System.currentTimeMillis(),best=Long.MAX_VALUE;int bi=0;String bn="--";for(int i=0;i<5;i++){Calendar c=parseToday(jamaat[i]);if(c==null)continue;if(c.getTimeInMillis()<=now)c.add(Calendar.DATE,1);if(c.getTimeInMillis()<best){best=c.getTimeInMillis();bn=names[i];bi=i;}}if(best!=Long.MAX_VALUE){nextMillis=best;nextName=bn;active=bi;}}
  String to12(String s){try{Date d=new SimpleDateFormat("HH:mm",Locale.US).parse(s);return new SimpleDateFormat("hh:mm a",Locale.US).format(d);}catch(Exception e){return s;}}
  long remainingMillis(){return Math.max(0,nextMillis-System.currentTimeMillis());}
  String countdown(){long d=remainingMillis()/1000;return String.format(Locale.US,"%02d:%02d:%02d",d/3600,(d%3600)/60,d%60);}
  void updateCountdownState(){if(nextMillis==0){computeNext();return;}long rem=remainingMillis();if(!countdownMode&&rem>0&&rem<=Prefs.countdownTrigger(MainActivity.this)*60000L){countdownMode=true;countdownTarget=nextMillis;bellPlayed=false;}if(countdownMode&&countdownTarget!=nextMillis){countdownMode=false;bellPlayed=false;}if(countdownMode&&rem<=0&&!bellPlayed){bellPlayed=true;playTwoBells();}}
  void playTwoBells(){try{if(bellPlayer!=null){bellPlayer.release();bellPlayer=null;}bellPlayer=MediaPlayer.create(this,R.raw.bell);if(bellPlayer==null){returnToMainAfterBell();return;}bellPlayer.setOnCompletionListener(mp->{mp.release();bellPlayer=null;new Handler().postDelayed(this::playSecondBell,650);});bellPlayer.start();}catch(Exception e){returnToMainAfterBell();}}
  void playSecondBell(){try{bellPlayer=MediaPlayer.create(this,R.raw.bell);if(bellPlayer==null){returnToMainAfterBell();return;}bellPlayer.setOnCompletionListener(mp->{mp.release();bellPlayer=null;returnToMainAfterBell();});bellPlayer.start();}catch(Exception e){returnToMainAfterBell();}}
  void returnToMainAfterBell(){new Handler().postDelayed(()->{countdownMode=false;computeNext();view.invalidate();},900);}

  class ModernView extends View{
    Paint p=new Paint(3),st=new Paint(3);String gregorian="",hijri=""; int W,H; final int BG=Color.rgb(6,36,28),PANEL=Color.rgb(10,55,42),GOLD=Color.rgb(232,195,94),CREAM=Color.rgb(247,240,215),MUTED=Color.rgb(181,201,191);
    ModernView(Context c){super(c);setFocusable(true);st.setStyle(Paint.Style.STROKE);}
    void txt(Canvas c,String s,float x,float y,float z,int col,Paint.Align a,boolean b){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(col);p.setTextSize(z);p.setTextAlign(a);p.setTypeface(Typeface.create("sans",b?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,x,y,p);}
    void box(Canvas c,float l,float t,float r,float b,int col,float rad){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(col);c.drawRoundRect(l,t,r,b,rad,rad,p);}
    void line(Canvas c,float x1,float y1,float x2,float y2,int col,float sw){st.setShader(null);st.setColor(col);st.setStrokeWidth(sw);st.setStyle(Paint.Style.STROKE);c.drawLine(x1,y1,x2,y2,st);}
    @Override protected void onDraw(Canvas c){W=getWidth();H=getHeight();updateCountdownState();drawBackdrop(c);if(countdownMode)drawCountdown(c);else drawMain(c);postInvalidateDelayed(500);}
    void drawBackdrop(Canvas c){c.drawColor(BG);p.setShader(new LinearGradient(0,0,W,H,Color.rgb(5,38,29),Color.rgb(12,66,51),Shader.TileMode.CLAMP));c.drawRect(0,0,W,H,p);p.setShader(null);drawOrnament(c,20,20,1);drawOrnament(c,W-20,20,-1);}
    void drawOrnament(Canvas c,float x,float y,float dir){st.setColor(0x5530a37c);st.setStrokeWidth(2);st.setStyle(Paint.Style.STROKE);for(int i=0;i<5;i++)c.drawCircle(x+dir*i*8,y+i*8,3+i*2,st);}
    void header(Canvas c){line(c,24,83,W-24,83,0x665f8b73,1);txt(c,"☪  "+Prefs.mosque(MainActivity.this),28,39,Math.min(25,W/58f),CREAM,Paint.Align.LEFT,true);txt(c,"B O K A R O ,  J H A R K H A N D",30,64,13,GOLD,Paint.Align.LEFT,false);txt(c,"☀  Sunrise  "+sunrise,W-260,40,20,CREAM,Paint.Align.LEFT,true);txt(c,hijri+"  |  "+gregorian,W-28,66,14,MUTED,Paint.Align.RIGHT,false);}
    void drawMain(Canvas c){
      header(c);
      // Compact TV dashboard: keep the information dense and readable from a distance.
      float top=96, cardTop=H*0.67f, bottom=cardTop-18;
      float leftW=W*0.205f, rightW=W*0.175f;
      drawJummah(c,24,top,leftW,bottom);
      drawClockAndNext(c,leftW+42,top,W-rightW-28);
      drawQRPanel(c,W-rightW,top,rightW-24,bottom);
      drawPrayerCards(c,24,cardTop,W-24,H-70);
      footer(c);
    }
    void drawJummah(Canvas c,float x,float y,float ww,float b){
      box(c,x,y,x+ww,b,PANEL,22);
      txt(c,"☀  Jumu'ah",x+20,y+36,20,GOLD,Paint.Align.LEFT,true);
      line(c,x+18,y+51,x+ww-18,y+51,0x665f8b73,1);
      labelValue(c,"Athan",Prefs.jumua1(MainActivity.this),x+20,y+88);
      labelValue(c,"Jamaat",Prefs.jumua2(MainActivity.this),x+20,y+151);
      labelValue(c,"Khutba",Prefs.khutba(MainActivity.this),x+20,y+214);
    }
    void labelValue(Canvas c,String a,String v,float x,float y){
      txt(c,a,x,y,13,MUTED,Paint.Align.LEFT,false);
      txt(c,v,x,y+27,24,CREAM,Paint.Align.LEFT,true);
    }
    void drawClockAndNext(Canvas c,float x,float y,float r){
      float clockX=x+92,cy=y+78,rad=Math.min(72,W*.075f);
      // Analog clock
      st.setColor(0x66ffffff);st.setStrokeWidth(2);st.setStyle(Paint.Style.STROKE);c.drawCircle(clockX,cy,rad+5,st);
      p.setColor(0xff0a3b2e);c.drawCircle(clockX,cy,rad,p);
      Calendar t=Calendar.getInstance();int sec=t.get(Calendar.SECOND),min=t.get(Calendar.MINUTE),hr=t.get(Calendar.HOUR);
      for(int i=0;i<60;i++){
        double a=Math.PI*2*i/60-Math.PI/2;float rr1=i%5==0?rad-13:rad-9;
        st.setColor(i%5==0?CREAM:0xff789b8c);st.setStrokeWidth(i%5==0?2.2f:1.1f);
        c.drawLine(clockX+(float)Math.cos(a)*rr1,cy+(float)Math.sin(a)*rr1,clockX+(float)Math.cos(a)*(rad-3),cy+(float)Math.sin(a)*(rad-3),st);
      }
      double ah=(hr+min/60.0)*Math.PI/6-Math.PI/2,am=(min+sec/60.0)*Math.PI/30-Math.PI/2;
      line(c,clockX,cy,clockX+(float)Math.cos(ah)*31,cy+(float)Math.sin(ah)*31,CREAM,5);
      line(c,clockX,cy,clockX+(float)Math.cos(am)*50,cy+(float)Math.sin(am)*50,GOLD,3.5f);
      p.setColor(GOLD);c.drawCircle(clockX,cy,4,p);

      float px=x+178,py=y+8,pw=r-px;
      box(c,px,py,r,py+142,0xff0d513d,25);
      txt(c,"☀  "+(langHi()?hindiPrayer(nextName):nextName)+" JAMAAT",px+22,py+35,19,GOLD,Paint.Align.LEFT,true);
      txt(c,jamaat[active],px+22,py+78,34,CREAM,Paint.Align.LEFT,true);
      txt(c,langHi()?"अगली जमाअत":"NEXT JAMAAT",r-20,py+111,12,MUTED,Paint.Align.RIGHT,true);
      txt(c,countdown(),r-20,py+134,17,GOLD,Paint.Align.RIGHT,true);
      txt(c,hijri,px+pw/2,py+181,16,CREAM,Paint.Align.CENTER,true);
      txt(c,gregorian,px+pw/2,py+204,14,MUTED,Paint.Align.CENTER,false);
    }
    void drawQRPanel(Canvas c,float x,float y,float ww,float b){
      box(c,x,y,x+ww,b,0xff0b4938,22);
      txt(c,"STAY CONNECTED",x+ww/2,y+30,12,GOLD,Paint.Align.CENTER,true);
      float size=Math.min(ww-34,118);drawQR(c,x+(ww-size)/2,y+46,size);
      txt(c,langHi()?"मस्जिद से जुड़े रहें":"Stay Connected",x+ww/2,y+46+size+28,13,CREAM,Paint.Align.CENTER,true);
      txt(c,langHi()?"ऐप डाउनलोड करें":"Download App",x+ww/2,y+46+size+49,12,MUTED,Paint.Align.CENTER,false);
    }
    void drawPrayerCards(Canvas c,float l,float y,float r,float b){
      float gap=9,cw=(r-l-gap*4)/5f;
      for(int i=0;i<5;i++){
        float x=l+i*(cw+gap);boolean a=i==active;
        box(c,x,y,x+cw,b,a?0xff123f31:0xff0b3027,17);
        if(a){st.setColor(GOLD);st.setStrokeWidth(2.5f);st.setStyle(Paint.Style.STROKE);c.drawRoundRect(x,y,x+cw,b,17,17,st);}
        txt(c,(i==0?"☀ ":i==4?"☾ ":"☀ ")+(langHi()?hindiPrayer(names[i]):names[i]),x+cw/2,y+29,16,a?GOLD:CREAM,Paint.Align.CENTER,true);
        txt(c,"Athan",x+cw/2,y+55,11,MUTED,Paint.Align.CENTER,false);
        txt(c,azan[i],x+cw/2,y+79,22,CREAM,Paint.Align.CENTER,true);
        txt(c,langHi()?"जमाअत":"Jamaat",x+cw/2,y+104,11,MUTED,Paint.Align.CENTER,false);
        txt(c,jamaat[i],x+cw/2,y+129,21,a?GOLD:CREAM,Paint.Align.CENTER,true);
      }
    }
    void footer(Canvas c){
      txt(c,langHi()?"📵 मोबाइल साइलेंट रखें":"📵 Keep Your Mobile Silent",W*.18f,H-25,12,CREAM,Paint.Align.CENTER,true);
      txt(c,langHi()?"सफ़ में शामिल हों":"Join The Row",W*.50f,H-25,12,CREAM,Paint.Align.CENTER,true);
      txt(c,langHi()?"अल्लाह पर ध्यान दें":"Focus On Allah",W*.82f,H-25,12,CREAM,Paint.Align.CENTER,true);
    }
    void drawCountdown(Canvas c){
      // premium countdown screen: large ring, compact header, preparation panel, QR panel
      txt(c,"☪  "+Prefs.mosque(MainActivity.this),28,40,Math.min(24,W/60f),CREAM,Paint.Align.LEFT,true);txt(c,"☀ Sunrise  "+sunrise,W-28,40,18,CREAM,Paint.Align.RIGHT,true);line(c,24,61,W-24,61,0x665f8b73,1);
      float cx=W*.50f,cy=H*.51f,rad=Math.min(H*.31f,W*.18f);box(c,0,0,W,H,0x12000000,0);txt(c,(langHi()?"जमाअत की तैयारी करें":"PREPARE FOR SALAH"),cx,H*.14f,18,GOLD,Paint.Align.CENTER,true);txt(c,(langHi()?""+hindiPrayer(nextName)+" जमाअत":""+nextName+" JAMAAT"),cx,H*.20f,31,CREAM,Paint.Align.CENTER,true);st.setColor(0x555f8b73);st.setStrokeWidth(14);c.drawCircle(cx,cy,rad,st);long trigger=Math.max(1,Prefs.countdownTrigger(MainActivity.this))*60000L;float progress=Math.max(0,Math.min(1,remainingMillis()/(float)trigger));st.setColor(GOLD);st.setStrokeWidth(14);c.drawArc(cx-rad,cy-rad,cx+rad,cy+rad,-90,360*progress,false,st);p.setColor(0xff082d23);c.drawCircle(cx,cy,rad-20,p);txt(c,String.format(Locale.US,"%02d:%02d",(remainingMillis()/1000)/60,(remainingMillis()/1000)%60),cx,cy+18,76,CREAM,Paint.Align.CENTER,true);txt(c,langHi()?"मिनट       सेकंड":"MINUTES      SECONDS",cx,cy+53,14,MUTED,Paint.Align.CENTER,true);txt(c,jamaat[active],cx,cy+92,24,GOLD,Paint.Align.CENTER,true);
      float lx=28,ly=H*.29f,lw=W*.23f;box(c,lx,ly,lx+lw,H*.78f,0xcc0b3c2f,22);txt(c,langHi()?"नमाज़ की तैयारी करें":"GET READY",lx+20,ly+36,19,GOLD,Paint.Align.LEFT,true);String[] hs=langHi()?new String[]{"वुज़ू करें","मस्जिद की तरफ निकलें","मोबाइल साइलेंट रखें","सफ़ में शामिल हों","अल्लाह की याद में लग जाएँ"}:new String[]{"Make Wudu","Head to the Masjid","Keep Your Phone Silent","Join the Row","Focus on Allah"};for(int i=0;i<hs.length;i++){txt(c,"•",lx+20,ly+78+i*43,22,GOLD,Paint.Align.LEFT,true);txt(c,hs[i],lx+40,ly+78+i*43,14,CREAM,Paint.Align.LEFT,false);}
      float rx=W*.80f;txt(c,langHi()?"हमसे जुड़े रहें":"STAY CONNECTED",rx,H*.31f,14,GOLD,Paint.Align.CENTER,true);drawQR(c,rx-65,H*.37f,130);txt(c,langHi()?"ऐप डाउनलोड करें":"Download App",rx,H*.58f,14,CREAM,Paint.Align.CENTER,true);txt(c,langHi()?"और नमाज़ कायम करो":"Establish Prayer",rx,H*.68f,17,GOLD,Paint.Align.CENTER,true);txt(c,hijri+"  |  "+gregorian,rx,H*.73f,13,MUTED,Paint.Align.CENTER,false);box(c,24,H-58,W-24,H-18,0xff092a22,14);txt(c,langHi()?"मोबाइल साइलेंट रखें   •   सफ़ में आगे बढ़ें   •   अल्लाह पर ध्यान दें":"Keep Mobile Silent   •   Join The Row   •   Focus On Allah",W/2,H-33,14,CREAM,Paint.Align.CENTER,true);
    }
    boolean langHi(){return Prefs.lang(MainActivity.this).equals("hi");}
    String hindiPrayer(String s){if("Fajr".equals(s))return "फ़ज्र";if("Dhuhr".equals(s))return "ज़ुहर";if("Asr".equals(s))return "अस्र";if("Maghrib".equals(s))return "मग़रिब";if("Isha".equals(s))return "इशा";return s;}
    void drawQR(Canvas c,float x,float y,float size){try{String q=Prefs.qr(MainActivity.this);BitMatrix m=new MultiFormatWriter().encode(q,BarcodeFormat.QR_CODE,140,140);p.setColor(Color.WHITE);c.drawRoundRect(x,y,x+size,y+size,8,8,p);p.setColor(Color.BLACK);float cell=size/140f;for(int yy=0;yy<140;yy++)for(int xx=0;xx<140;xx++)if(m.get(xx,yy))c.drawRect(x+xx*cell,y+yy*cell,x+(xx+1)*cell,y+(yy+1)*cell,p);}catch(Exception ignored){}}
    @Override public boolean onKeyUp(int key,KeyEvent e){if(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_MENU||key==KeyEvent.KEYCODE_SETTINGS){startActivity(new Intent(MainActivity.this,SettingsActivity.class));return true;}return super.onKeyUp(key,e);}
  }
}
