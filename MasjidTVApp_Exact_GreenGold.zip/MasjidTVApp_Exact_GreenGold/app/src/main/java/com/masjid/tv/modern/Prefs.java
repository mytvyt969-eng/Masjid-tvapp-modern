package com.masjid.tv.modern;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {
  private static SharedPreferences p(Context c){ return c.getSharedPreferences("masjid_modern", Context.MODE_PRIVATE); }
  public static String mosque(Context c){return p(c).getString("mosque","JAMA MASJID KODWATAND, LALPANIA");}
  public static String lat(Context c){return p(c).getString("lat","23.78");}
  public static String lon(Context c){return p(c).getString("lon","85.50");}
  public static String method(Context c){return p(c).getString("method","1");}
  public static String qr(Context c){return p(c).getString("qr","https://example.com");}
  public static String azan(Context c,int i){return p(c).getString("azan"+i,new String[]{"04:30 AM","01:00 PM","04:15 PM","05:55 PM","07:45 PM"}[i]);}
  public static String jamaat(Context c,int i){return p(c).getString("jamaat"+i,new String[]{"05:00 AM","01:15 PM","04:30 PM","05:58 PM","08:00 PM"}[i]);}
  public static String jumua1(Context c){return p(c).getString("jumua1","01:00 PM");}
  public static String jumua2(Context c){return p(c).getString("jumua2","01:00 PM");}
  public static String khutba(Context c){return p(c).getString("khutba","01:00 PM");}
  public static int countdownTrigger(Context c){return p(c).getInt("countdownTrigger",3);}
  public static String lang(Context c){return p(c).getString("lang","en");}
  public static void save(Context c,String mosque,String lat,String lon,String method,String qr,String[] azan,String[] jamaat,String j1,String j2,String kh,int trigger,String lang){
    SharedPreferences.Editor e=p(c).edit().putString("mosque",mosque).putString("lat",lat).putString("lon",lon).putString("method",method).putString("qr",qr).putString("jumua1",j1).putString("jumua2",j2).putString("khutba",kh).putInt("countdownTrigger",trigger).putString("lang",lang);
    for(int i=0;i<5;i++){e.putString("azan"+i,azan[i]);e.putString("jamaat"+i,jamaat[i]);} e.apply();
  }
}
