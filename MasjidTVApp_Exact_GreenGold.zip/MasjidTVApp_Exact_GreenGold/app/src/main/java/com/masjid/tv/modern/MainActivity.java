package com.masjid.tv.modern;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.media.*;import android.view.*;import java.text.*;import java.util.*;import java.util.concurrent.*;import org.json.*;import java.io.*;import java.net.*;import com.google.zxing.*;import com.google.zxing.common.BitMatrix;

public class MainActivity extends Activity {
  ModernView view; ExecutorService exec=Executors.newSingleThreadExecutor(); String[] names={"Fajr","Dhuhr","Asr","Maghrib","Isha"}; String[] azan=new String[5],jamaat=new String[5];
  String sunrise="--:--"; int active=0; long nextMillis=0; String nextName="--"; boolean countdownMode=false,bellPlayed=false; long countdownTarget=0; MediaPlayer bellPlayer;
  @Override public void onCreate(Bundle b){super.onCreate(b);fullscreen();view=new ModernView(this);setContentView(view);loadSaved();fetchTimes();}
  void fullscreen(){getWindow().setFlags(1024,1024);getWindow().getDecorView().setSystemUiVisibility(5894);}
  void loadSaved(){for(int i=0;i<5;i++){azan[i]=Prefs.azan(this,i);jamaat[i]=Prefs.jamaat(this,i);}}
  @Override protected void onResume(){super.onResume();fullscreen();if(view!=null){loadSaved();view.invalidate();}fetchTimes();}
  @Override protected void onDestroy(){if(bellPlayer!=null){bellPlayer.release();bellPlayer=null;}exec.shutdownNow();super.onDestroy();}
  void fetchTimes(){final String lat=Prefs.lat(this),lon=Prefs.lon(this),method=Prefs.method(this);exec.execute(()->{try{URL u=new URL("https://api.aladhan.com/v1/timings?latitude="+URLEncoder.encode(lat,"UTF-8")+"&longitude="+URLEncoder.encode(lon,"UTF-8")+"&method="+method);HttpURLConnection h=(HttpURLConnection)u.openConnection();h.setConnectTimeout(8000);h.setReadTimeout(8000);BufferedReader r=new BufferedReader(new InputStreamReader(h.getInputStream()));StringBuilder s=new StringBuilder();String line;while((line=r.readLine())!=null)s.append(line);r.close();JSONObject data=new JSONObject(s.toString()).getJSONObject("data"),t=data.getJSONObject("timings");String[] keys={"Fajr","Dhuhr","Asr","Maghrib","Isha"};for(int i=0;i<5;i++)azan[i]=to12(t.getString(keys[i]));sunrise=to12(t.getString("Sunrise"));JSONObject gd=data.getJSONObject("date").getJSONObject("gregorian"),hd=data.getJSONObject("date").getJSONObject("hijri");view.gregorian=gd.getString("weekday")+", "+gd.getString("date");view.hijri=hd.getJSONObject("month").getString("en")+" "+hd.getString("day")+", "+hd.getString("year");computeNext();runOnUiThread(()->view.invalidate());}catch(Exception e){computeNext();runOnUiThread(()->view.invalidate());}});}
  Calendar parseToday(String text){try{Date d=new SimpleDateFormat("hh:mm a",Locale.US).parse(text);Calendar now=Calendar.getInstance(),x=Calendar.getInstance();x.setTime(d);now.set(Calendar.HOUR_OF_DAY,x.get(Calendar.HOUR_OF_DAY));now.set(Calendar.MINUTE,x.get(Calendar.MINUTE));now.set(Calendar.SECOND,0);now.set(Calendar.MILLISECOND,0);return now;}catch(Exception e){return null;}}
  void computeNext(){long now=System.currentTimeMillis(),best=Long.MAX_VALUE;int bi=0;String bn="--";for(int i=0;i<5;i++){Calendar c=parseToday(jamaat[i]);if(c==null)continue;if(c.getTimeInMillis()<=now)c.add(Calendar.DATE,1);if(c.getTimeInMillis()<best){best=c.getTimeInMillis();bn=names[i];bi=i;}}if(best!=Long.MAX_VALUE){nextMillis=best;nextName=bn;active=bi;}}
  String to12(String s){try{Date d=new SimpleDateFormat("HH:mm",Locale.US).parse(s);return new SimpleDateFormat("hh:mm a",Locale.US).format(d);}catch(Exception e){return s;}}
  long remainingMillis(){return Math.max(0,nextMillis-System.currentTimeMillis());}
  String countdown(){long d=remainingMillis()/1000;return String.format(Locale.US,"%02d:%02d:%02d",d/3600,(d%3600)/60,d%60);}
  void updateCountdownState(){if(nextMillis==0){computeNext();return;}long rem=remainingMillis();if(!countdownMode&&rem>0&&rem<=Prefs.countdownTrigger(MainActivity.this)*60000L){countdownMode=true;countdownTarget=nextMillis;bellPlayed=false;}if(countdownMode&&countdownTarget!=nextMillis){countdownMode=false;bellPlayed=false;}if(countdownMode&&rem<=0&&!bellPlayed){bellPlayed=true;playTwoBells();}}
  void playTwoBells(){try{if(bellPlayer!=null){bellPlayer.release();bellPlayer=null;}bellPlayer=MediaPlayer.create(this,R.raw.bell);if(bellPlayer==null){returnToMainAfterBell();return;}bellPlayer.setOnCompletionListener(mp->{mp.release();bellPlayer=null;new Handler().postDelayed(this::playSecondBell,650);});bellPlayer.start();}catch(Exception e){returnToMainAfterBell();}}
  void playSecondBell(){try{bellPlayer=MediaPlayer.create(this,R.raw.bell);if(bellPlayer==null){returnToMainAfterBell();return;}bellPlayer.setOnCompletionListener(mp->{mp.release();bellPlayer=null;returnToMainAfterBell();});bellPlayer.start();}catch(Exception e){returnToMainAfterBell();}}
  void returnToMainAfterBell(){new Handler().postDelayed(()->{countdownMode=false;computeNext();view.invalidate();},900);}

  class ModernView extends View{
    Paint p=new Paint(Paint.ANTI_ALIAS_FLAG), st=new Paint(Paint.ANTI_ALIAS_FLAG);
    String gregorian="",hijri=""; int W,H;
    final int BG=Color.rgb(4,45,38), DEEP=Color.rgb(3,35,30), PANEL=Color.rgb(5,77,64), PANEL2=Color.rgb(4,91,73);
    final int TEAL=Color.rgb(7,142,111), GOLD=Color.rgb(245,211,68), CREAM=Color.rgb(250,247,226), MUTED=Color.rgb(188,214,204);
    ModernView(Context c){super(c);setFocusable(true);st.setStyle(Paint.Style.STROKE);}
    void txt(Canvas c,String s,float x,float y,float z,int col,Paint.Align a,boolean bold){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(col);p.setTextSize(z);p.setTextAlign(a);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,x,y,p);}
    void box(Canvas c,float l,float t,float r,float b,int col,float rad){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(col);c.drawRoundRect(l,t,r,b,rad,rad,p);}
    void strokeBox(Canvas c,float l,float t,float r,float b,int col,float sw,float rad){st.setShader(null);st.setStyle(Paint.Style.STROKE);st.setStrokeWidth(sw);st.setColor(col);c.drawRoundRect(l,t,r,b,rad,rad,st);}
    void line(Canvas c,float x1,float y1,float x2,float y2,int col,float sw){st.setShader(null);st.setColor(col);st.setStrokeWidth(sw);st.setStyle(Paint.Style.STROKE);c.drawLine(x1,y1,x2,y2,st);}
    void iconSun(Canvas c,float x,float y,float r,int col){p.setColor(col);p.setStyle(Paint.Style.FILL);c.drawCircle(x,y,r*.45f,p);st.setColor(col);st.setStrokeWidth(Math.max(2,r*.12f));for(int i=0;i<8;i++){double a=i*Math.PI/4;c.drawLine(x+(float)Math.cos(a)*r*.65f,y+(float)Math.sin(a)*r*.65f,x+(float)Math.cos(a)*r,y+(float)Math.sin(a)*r,st);}}
    void iconMoon(Canvas c,float x,float y,float r,int col){p.setColor(col);p.setStyle(Paint.Style.FILL);c.drawCircle(x,y,r,p);p.setColor(PANEL);c.drawCircle(x+r*.35f,y-r*.25f,r*.82f,p);}
    void mosqueSilhouette(Canvas c){
      p.setColor(0x2638b79a);p.setStyle(Paint.Style.FILL);
      float base=H*.78f;
      c.drawRect(0,base,W,H,p);
      for(int i=0;i<9;i++){float x=i*W/8f;float h=(i%3==0?H*.20f:H*.10f);c.drawRect(x-5,base-h,x+5,base,p);c.drawCircle(x,base-h,10,p);}
      float cx=W*.62f; c.drawRect(cx-155,base-60,cx+155,base,p);c.drawOval(cx-95,base-145,cx+95,base-25,p);c.drawRect(cx-20,base-205,cx+20,base-70,p);c.drawCircle(cx,base-210,12,p);c.drawOval(cx-235,base-105,cx-115,base-20,p);c.drawOval(cx+115,base-105,cx+235,base-20,p);
    }
    @Override protected void onDraw(Canvas c){W=getWidth();H=getHeight();updateCountdownState();drawBackdrop(c);if(countdownMode)drawCountdown(c);else drawMain(c);postInvalidateDelayed(500);}
    void drawBackdrop(Canvas c){p.setShader(new LinearGradient(0,0,W,H,Color.rgb(3,42,35),Color.rgb(5,105,83),Shader.TileMode.CLAMP));c.drawRect(0,0,W,H,p);p.setShader(null);mosqueSilhouette(c);drawCorner(c,0,0,1,1);drawCorner(c,W,0,-1,1);}
    void drawCorner(Canvas c,float x,float y,float sx,float sy){st.setColor(0x5547a98c);st.setStrokeWidth(2);for(int i=0;i<7;i++){c.drawArc(x+sx*(i*5-20),y+sy*(i*5-20),x+sx*(70+i*5),y+sy*(70+i*5),i*8,70,false,st);}}
    void header(Canvas c){
      float fs=Math.min(27,W/55f);
      txt(c,"☪  "+Prefs.mosque(MainActivity.this),30,40,fs,CREAM,Paint.Align.LEFT,true);
      txt(c,"B O K A R O ,  J H A R K H A N D",31,65,13,GOLD,Paint.Align.LEFT,true);
      iconSun(c,W*.735f,31,16,GOLD);txt(c,"Sunrise",W*.755f,29,15,CREAM,Paint.Align.LEFT,true);txt(c,sunrise,W*.755f,53,24,CREAM,Paint.Align.LEFT,true);
      line(c,W*.84f,14,W*.84f,62,0x77ffffff,1);
      txt(c,hijri,W*.86f,31,14,CREAM,Paint.Align.LEFT,true);txt(c,gregorian,W*.86f,53,13,MUTED,Paint.Align.LEFT,false);
      line(c,24,78,W-24,78,0x6693c4b3,1);
    }
    void drawMain(Canvas c){
      header(c);
      float top=94, bottom=H*.66f, gap=16;
      float left=W*.19f, right=W*.145f, centerL=24+left+gap, centerR=W-right-24-gap;
      drawJummah(c,24,top,left,bottom);
      drawHero(c,centerL,top,centerR,bottom);
      drawQRPanel(c,W-right,top,right-24,bottom);
      drawPrayerCards(c,24,H*.685f,W-24,H-55);
      footer(c);
    }
    void drawJummah(Canvas c,float x,float y,float ww,float b){
      box(c,x,y,x+ww,b,0xcc075344,18);strokeBox(c,x,y,x+ww,b,0x668ed4bf,1,18);
      txt(c,"▣  Jumu'ah",x+20,y+38,21,GOLD,Paint.Align.LEFT,true);line(c,x+18,y+53,x+ww-18,y+53,0x6693c4b3,1);
      labelValue(c,"Athan",Prefs.jumua1(MainActivity.this),x+22,y+94);labelValue(c,"Jamaat",Prefs.jumua2(MainActivity.this),x+22,y+166);labelValue(c,"Khutba",Prefs.khutba(MainActivity.this),x+22,y+238);
    }
    void labelValue(Canvas c,String a,String v,float x,float y){txt(c,a,x,y,13,MUTED,Paint.Align.LEFT,true);txt(c,v,x,y+31,26,CREAM,Paint.Align.LEFT,true);}
    void drawHero(Canvas c,float l,float y,float r,float b){
      float h=b-y;box(c,l,y,r,b,0x330b8068,22);strokeBox(c,l,y,r,b,0x668ed4bf,1,22);
      float clockX=l+105,cy=y+78,rad=Math.min(68,W*.072f);drawClock(c,clockX,cy,rad);
      float tx=l+190;String nm=langHi()?hindiPrayer(nextName):nextName;
      iconSun(c,tx+16,y+32,13,GOLD);txt(c,nm+" Jamaat",tx+42,y+41,22,CREAM,Paint.Align.LEFT,true);
      txt(c,jamaat[active],tx,y+92,Math.min(48,W/31f),CREAM,Paint.Align.LEFT,true);
      txt(c,"NEXT JAMAAT",r-22,y+113,12,MUTED,Paint.Align.RIGHT,true);txt(c,countdown(),r-22,y+139,20,GOLD,Paint.Align.RIGHT,true);
      txt(c,hijri,l+(r-l)*.52f,y+h*.76f,15,CREAM,Paint.Align.CENTER,true);txt(c,gregorian,l+(r-l)*.52f,y+h*.86f,14,MUTED,Paint.Align.CENTER,false);
    }
    void drawClock(Canvas c,float x,float y,float rad){
      p.setColor(CREAM);p.setStyle(Paint.Style.FILL);c.drawCircle(x,y,rad,p);st.setColor(GOLD);st.setStrokeWidth(5);st.setStyle(Paint.Style.STROKE);c.drawCircle(x,y,rad+5,st);
      Calendar t=Calendar.getInstance();int sec=t.get(Calendar.SECOND),min=t.get(Calendar.MINUTE),hr=t.get(Calendar.HOUR);
      for(int i=0;i<12;i++){double a=i*Math.PI/6-Math.PI/2;txt(c,""+(i==0?12:i),x+(float)Math.cos(a)*(rad-18),y+(float)Math.sin(a)*(rad-18)+6,13,DEEP,Paint.Align.CENTER,true);}
      double ah=(hr+min/60.0)*Math.PI/6-Math.PI/2,am=(min+sec/60.0)*Math.PI/30-Math.PI/2;
      line(c,x,y,x+(float)Math.cos(ah)*31,y+(float)Math.sin(ah)*31,DEEP,5);line(c,x,y,x+(float)Math.cos(am)*45,y+(float)Math.sin(am)*45,DEEP,3);p.setColor(GOLD);c.drawCircle(x,y,4,p);
    }
    void drawQRPanel(Canvas c,float x,float y,float ww,float b){
      box(c,x,y,x+ww,b,0xcc075344,18);strokeBox(c,x,y,x+ww,b,0x668ed4bf,1,18);txt(c,"STAY CONNECTED",x+ww/2,y+30,11,GOLD,Paint.Align.CENTER,true);float size=Math.min(ww-25,112);drawQR(c,x+(ww-size)/2,y+46,size);txt(c,"Scan To Stay",x+ww/2,y+46+size+25,13,CREAM,Paint.Align.CENTER,true);txt(c,"Connected!",x+ww/2,y+46+size+45,13,CREAM,Paint.Align.CENTER,true);
    }
    void drawPrayerCards(Canvas c,float l,float y,float r,float b){
      float gap=10,cw=(r-l-gap*4)/5f;
      for(int i=0;i<5;i++){float x=l+i*(cw+gap);boolean a=i==active;int fill=a?0xdd0b5d49:0xcc06483a;box(c,x,y,x+cw,b,fill,17);if(a){strokeBox(c,x,y,x+cw,b,GOLD,3,17);}else strokeBox(c,x,y,x+cw,b,0x667bc3ae,1,17);
        if(i==4)iconMoon(c,x+cw*.23f,y+29,10,GOLD);else iconSun(c,x+cw*.23f,y+29,9,GOLD);
        txt(c,langHi()?hindiPrayer(names[i]):names[i],x+cw*.62f,y+36,18,a?GOLD:CREAM,Paint.Align.CENTER,true);line(c,x+18,y+50,x+cw-18,y+50,0x6693c4b3,1);
        txt(c,"Athan",x+cw/2,y+76,11,MUTED,Paint.Align.CENTER,false);txt(c,azan[i],x+cw/2,y+104,22,CREAM,Paint.Align.CENTER,true);txt(c,"Jamaat",x+cw/2,y+133,11,MUTED,Paint.Align.CENTER,false);txt(c,jamaat[i],x+cw/2,y+163,22,a?GOLD:CREAM,Paint.Align.CENTER,true);
      }
    }
    void footer(Canvas c){line(c,24,H-42,W-24,H-42,0x6693c4b3,1);txt(c,"▣  "+(langHi()?"मोबाइल साइलेंट रखें":"Keep Your Mobile Silent"),W*.17f,H-17,12,CREAM,Paint.Align.CENTER,true);txt(c,langHi()?"सफ़ में शामिल हों":"Join The Row",W*.50f,H-17,12,CREAM,Paint.Align.CENTER,true);txt(c,langHi()?"अल्लाह पर ध्यान दें":"Focus On Allah",W*.83f,H-17,12,CREAM,Paint.Align.CENTER,true);}
    void drawCountdown(Canvas c){
      header(c);float cx=W*.50f,cy=H*.50f,rad=Math.min(H*.30f,W*.18f);txt(c,langHi()?"जमाअत की तैयारी करें":"PREPARE FOR SALAH",cx,H*.15f,19,GOLD,Paint.Align.CENTER,true);txt(c,(langHi()?hindiPrayer(nextName):nextName)+" JAMAAT",cx,H*.21f,31,CREAM,Paint.Align.CENTER,true);st.setColor(0x6689b9aa);st.setStrokeWidth(15);c.drawCircle(cx,cy,rad,st);long trigger=Math.max(1,Prefs.countdownTrigger(MainActivity.this))*60000L;float progress=Math.max(0,Math.min(1,remainingMillis()/(float)trigger));st.setColor(GOLD);st.setStrokeWidth(15);c.drawArc(cx-rad,cy-rad,cx+rad,cy+rad,-90,360*progress,false,st);p.setColor(DEEP);c.drawCircle(cx,cy,rad-22,p);txt(c,String.format(Locale.US,"%02d:%02d",(remainingMillis()/1000)/60,(remainingMillis()/1000)%60),cx,cy+20,Math.min(70,W/20f),CREAM,Paint.Align.CENTER,true);txt(c,"MINUTES      SECONDS",cx,cy+54,14,MUTED,Paint.Align.CENTER,true);txt(c,jamaat[active],cx,cy+92,25,GOLD,Paint.Align.CENTER,true);
      float lx=25,ly=H*.30f,lw=W*.23f;box(c,lx,ly,lx+lw,H*.78f,0xdd075344,20);txt(c,langHi()?"नमाज़ की तैयारी करें":"GET READY",lx+20,ly+36,19,GOLD,Paint.Align.LEFT,true);String[] hs=langHi()?new String[]{"वुज़ू करें","मस्जिद की तरफ निकलें","मोबाइल साइलेंट रखें","सफ़ में शामिल हों","अल्लाह की याद में लग जाएँ"}:new String[]{"Make Wudu","Head to the Masjid","Keep Your Phone Silent","Join The Row","Focus on Allah"};for(int i=0;i<hs.length;i++){txt(c,"•",lx+20,ly+78+i*43,22,GOLD,Paint.Align.LEFT,true);txt(c,hs[i],lx+40,ly+78+i*43,14,CREAM,Paint.Align.LEFT,false);}
      float rx=W*.82f;txt(c,"STAY CONNECTED",rx,H*.31f,13,GOLD,Paint.Align.CENTER,true);drawQR(c,rx-60,H*.36f,120);txt(c,"Download App",rx,H*.58f,14,CREAM,Paint.Align.CENTER,true);txt(c,hijri,rx,H*.68f,14,CREAM,Paint.Align.CENTER,true);txt(c,gregorian,rx,H*.72f,13,MUTED,Paint.Align.CENTER,false);box(c,24,H-56,W-24,H-18,0xdd063128,13);txt(c,"Keep Mobile Silent   •   Join The Row   •   Focus on Allah",W/2,H-32,14,CREAM,Paint.Align.CENTER,true);
    }
    boolean langHi(){return Prefs.lang(MainActivity.this).equals("hi");}
    String hindiPrayer(String s){if("Fajr".equals(s))return "फ़ज्र";if("Dhuhr".equals(s))return "ज़ुहर";if("Asr".equals(s))return "अस्र";if("Maghrib".equals(s))return "मग़रिब";if("Isha".equals(s))return "इशा";return s;}
    void drawQR(Canvas c,float x,float y,float size){try{String q=Prefs.qr(MainActivity.this);BitMatrix m=new MultiFormatWriter().encode(q,BarcodeFormat.QR_CODE,140,140);p.setColor(Color.WHITE);c.drawRoundRect(x,y,x+size,y+size,6,6,p);p.setColor(Color.BLACK);float cell=size/140f;for(int yy=0;yy<140;yy++)for(int xx=0;xx<140;xx++)if(m.get(xx,yy))c.drawRect(x+xx*cell,y+yy*cell,x+(xx+1)*cell,y+(yy+1)*cell,p);}catch(Exception ignored){}}
    @Override public boolean onKeyUp(int key,KeyEvent e){if(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_MENU||key==KeyEvent.KEYCODE_SETTINGS){startActivity(new Intent(MainActivity.this,SettingsActivity.class));return true;}return super.onKeyUp(key,e);}
  }
}
