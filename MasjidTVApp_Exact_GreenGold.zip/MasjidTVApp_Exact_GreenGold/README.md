# Masjid TV Modern

A separate Android TV version of the Masjid TV display. The original `com.masjid.tv` app is untouched.

## Design
- Deep green + gold mosque theme
- Large professional prayer cards
- Redesigned circular countdown screen
- English/Hindi display setting
- Jumu'ah panel, sunrise, Hijri/Gregorian date and QR panel
- Countdown to Jamaat with two-bell alert
- Android TV fullscreen / landscape

## Build
Use GitHub Actions and download the `MasjidTVModern-debug-apk` artifact.
